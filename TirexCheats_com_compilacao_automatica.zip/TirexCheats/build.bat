@echo off
setlocal
py -m pip install --upgrade pip
py -m pip install pyinstaller
py -m PyInstaller --noconfirm --clean --onefile --windowed --name TirexCheats app.py
echo.
echo Pronto! O executavel estará em dist\TirexCheats.exe
pause
