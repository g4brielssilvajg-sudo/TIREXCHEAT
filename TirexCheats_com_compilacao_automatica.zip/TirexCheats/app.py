import tkinter as tk
from tkinter import ttk
from datetime import date

APP_NAME = "TIREX CHEATS"
EXPIRATION_DATE = date(2033, 12, 31)

def main():
    root = tk.Tk()
    root.title(APP_NAME)
    root.geometry("520x330")
    root.minsize(460, 300)
    root.configure(bg="#10131a")

    style = ttk.Style()
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure("TButton", font=("Segoe UI", 10), padding=8)

    header = tk.Frame(root, bg="#191f2b", height=92)
    header.pack(fill="x")
    header.pack_propagate(False)

    title = tk.Label(
        header, text=APP_NAME, bg="#191f2b", fg="#73e0b5",
        font=("Segoe UI", 22, "bold")
    )
    title.pack(pady=(18, 0))

    subtitle = tk.Label(
        header, text="Projeto independente", bg="#191f2b", fg="#c4cbd7",
        font=("Segoe UI", 10)
    )
    subtitle.pack()

    content = tk.Frame(root, bg="#10131a", padx=28, pady=24)
    content.pack(fill="both", expand=True)

    tk.Label(
        content, text="Status do projeto", bg="#10131a", fg="#f2f5fa",
        font=("Segoe UI", 12, "bold")
    ).pack(anchor="w")

    today = date.today()
    if today <= EXPIRATION_DATE:
        status_text = "Interface demonstrativa ativa"
        status_color = "#73e0b5"
    else:
        status_text = "Prazo configurado encerrado"
        status_color = "#ff7b7b"

    tk.Label(
        content, text=status_text, bg="#10131a", fg=status_color,
        font=("Segoe UI", 10)
    ).pack(anchor="w", pady=(7, 14))

    expiry = EXPIRATION_DATE.strftime("%d/%m/%Y")
    tk.Label(
        content, text=f"Validade configurada: {expiry}",
        bg="#10131a", fg="#c4cbd7", font=("Segoe UI", 10)
    ).pack(anchor="w")

    tk.Label(
        content,
        text="Esta é uma interface independente de demonstração.\n"
             "Ela não altera nem remove licenças de outros programas.",
        bg="#10131a", fg="#8f9aab", font=("Segoe UI", 9),
        justify="left", wraplength=440
    ).pack(anchor="w", pady=(18, 18))

    ttk.Button(content, text="Fechar", command=root.destroy).pack(anchor="e")
    root.mainloop()

if __name__ == "__main__":
    main()
